package org.upv.myfinances.model;

public enum AccountType {
    CheckingAccount,
    Cash,
    Savings,
    Inverstment,
    Others
}
