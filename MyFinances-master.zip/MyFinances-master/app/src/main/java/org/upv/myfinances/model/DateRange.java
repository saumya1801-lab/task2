package org.upv.myfinances.model;

public enum DateRange {
    Daily,
    Weekly,
    Monthly,
    Yearly
}
