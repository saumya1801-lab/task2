package org.upv.myfinances.model;

public enum CreditCardType {
    Visa,
    MasterCard,
    AmericanExpress,
    DinersClub,
    Other
}
